package routines.system;

/**
 * store some global constant
 * @author Administrator
 *
 */
public abstract class Constant {
	
	/**
	 * the default pattern for date parse and format
	 */
	public static final String dateDefaultPattern = "dd-MM-yyyy";

}
